# 3D CSS Party Chopper 🎉

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/WNRjxjP](https://codepen.io/jh3y/pen/WNRjxjP).

