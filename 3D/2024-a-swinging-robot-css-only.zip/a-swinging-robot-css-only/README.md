# A swinging robot (CSS only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/QWXOYvz](https://codepen.io/amit_sheen/pen/QWXOYvz).

